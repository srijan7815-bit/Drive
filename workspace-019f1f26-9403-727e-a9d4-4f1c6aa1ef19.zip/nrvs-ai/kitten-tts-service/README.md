# KittenTTS service (reference)

NRVS's `/api/tts` proxy forwards to a KittenTTS HTTP service. KittenTTS is a
Python/ONNX package, so it can't run inside the Node serverless function — host
this tiny service anywhere that runs Python (Render, Fly.io, Railway, a VPS, or
a Hugging Face Space) and set `KITTEN_TTS_URL` in your Vercel env to its `/tts`
endpoint.

## Run locally

```bash
cd kitten-tts-service
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
# -> http://localhost:8000/tts
```

Then in NRVS (Vercel env, or .env.local for `vercel dev`):

```
KITTEN_TTS_URL=http://localhost:8000/tts
# KITTEN_TTS_KEY=some-shared-secret   # optional; if set, must match server
```

## Contract

`POST /tts`  body: `{ "text": "...", "voice": "Jasper", "speed": 1.0 }`
→ returns `audio/wav` bytes.

Voices: Bella, Jasper, Luna, Bruno, Rosie, Hugo, Kiki, Leo.

"""Minimal KittenTTS HTTP service for NRVS.

Exposes POST /tts { text, voice, speed } -> audio/wav bytes.
Set the env var KITTEN_TTS_KEY to require a matching bearer token
(the same value you set as KITTEN_TTS_KEY in NRVS/Vercel).

Run:
    uvicorn server:app --host 0.0.0.0 --port 8000
"""
import io
import os

import numpy as np
import soundfile as sf
from fastapi import FastAPI, Header, HTTPException, Response
from pydantic import BaseModel

from kittentts import KittenTTS

app = FastAPI(title="NRVS KittenTTS service")

# Load once at startup (downloads the model on first run, then caches it).
MODEL_NAME = os.environ.get("KITTEN_MODEL", "KittenML/kitten-tts-mini-0.8")
model = KittenTTS(MODEL_NAME)

VALID_VOICES = {"Bella", "Jasper", "Luna", "Bruno", "Rosie", "Hugo", "Kiki", "Leo"}
SHARED_KEY = os.environ.get("KITTEN_TTS_KEY")  # optional


class TTSRequest(BaseModel):
    text: str
    voice: str = "Jasper"
    speed: float = 1.0


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_NAME}


@app.post("/tts")
def tts(req: TTSRequest, authorization: str | None = Header(default=None)):
    # Optional shared-secret auth.
    if SHARED_KEY:
        expected = f"Bearer {SHARED_KEY}"
        if authorization != expected:
            raise HTTPException(status_code=401, detail="Unauthorized")

    text = (req.text or "").strip()[:5000]
    if not text:
        raise HTTPException(status_code=400, detail="text is required")

    voice = req.voice if req.voice in VALID_VOICES else "Jasper"
    speed = float(req.speed) if req.speed else 1.0
    speed = min(max(speed, 0.5), 2.0)

    try:
        audio = model.generate(text, voice=voice, speed=speed, clean_text=True)
    except Exception as e:  # pragma: no cover
        raise HTTPException(status_code=502, detail=f"synthesis failed: {e}")

    buf = io.BytesIO()
    sf.write(buf, np.asarray(audio), 24000, format="WAV")
    buf.seek(0)
    return Response(content=buf.read(), media_type="audio/wav")

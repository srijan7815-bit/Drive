// GET /api/auth-check — Diagnostic endpoint to verify Supabase OAuth config.
// Returns whether Google OAuth provider is configured and the Supabase URL is reachable.

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'application/json')

  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS')
    res.statusCode = 204
    res.end()
    return
  }

  if (req.method !== 'GET') {
    res.statusCode = 405
    res.end(JSON.stringify({ error: 'Method not allowed' }))
    return
  }

  const SUP_URL = process.env.VITE_SUPABASE_URL
  const ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY
  const SR = process.env.SUPABASE_SERVICE_ROLE_KEY

  const result = {
    timestamp: new Date().toISOString(),
    supabase_url: SUP_URL ? 'set' : 'missing',
    anon_key: ANON_KEY ? 'set' : 'missing',
    service_role_key: SR ? 'set' : 'missing',
    supabase_reachable: false,
    google_oauth_configured: false,
    settings_check: null,
  }

  if (!SUP_URL || !ANON_KEY) {
    res.statusCode = 200
    res.end(JSON.stringify(result))
    return
  }

  // Test 1: Can we reach Supabase?
  try {
    const healthResp = await fetch(`${SUP_URL}/rest/v1/`, {
      headers: { apikey: ANON_KEY },
      signal: AbortSignal.timeout(8000),
    })
    result.supabase_reachable = true
    result.supabase_status = healthResp.status
  } catch (e) {
    result.supabase_reachable = false
    result.supabase_error = e.message
  }

  // Test 2: Check if Google OAuth provider is configured via the GoTrue settings
  try {
    const settingsResp = await fetch(`${SUP_URL}/auth/v1/settings`, {
      headers: { apikey: ANON_KEY },
      signal: AbortSignal.timeout(8000),
    })
    if (settingsResp.ok) {
      const settings = await settingsResp.json()
      // settings.external is an object like {google: true, email: true, ...}
      const ext = settings.external || {}
      const providerList = Object.entries(ext).filter(([, v]) => v).map(([k]) => k)
      result.settings_check = {
        providers: providerList,
        has_google: Boolean(ext.google),
        mailer_autoconfirm: settings.mailer_autoconfirm,
      }
      result.google_oauth_configured = Boolean(ext.google)
    } else {
      result.settings_check = { error: `HTTP ${settingsResp.status}`, body: await settingsResp.text().catch(() => '') }
    }
  } catch (e) {
    result.settings_check = { error: e.message }
  }

  res.statusCode = 200
  res.end(JSON.stringify(result, null, 2))
}

// POST /api/tts  { text, voice?, speed? }  ->  audio/wav bytes
//
// Proxy to a KittenTTS service (https://github.com/KittenML/KittenTTS).
// KittenTTS is a Python/ONNX package, so it can't run inside this Node
// serverless function directly. Instead we forward the request to a Kitten
// service you host (e.g. a small FastAPI/HF Space) whose URL is configured via
// the KITTEN_TTS_URL environment variable.
//
// If KITTEN_TTS_URL is not set, we return 503 so the client transparently
// falls back to the browser's built-in speech synthesis — nothing breaks.
//
// Expected upstream contract (either works):
//   A) Returns raw audio bytes with an audio/* Content-Type.
//   B) Returns JSON { audio: "<base64 wav>", format?: "wav" }.
// Request sent upstream: POST { text, voice, speed } (+ optional bearer via
// KITTEN_TTS_KEY). Adjust to match your service if needed.

import { requireAuth, setCORS, sendError, parseBody } from './_lib/auth.js'

export const config = { maxDuration: 30 }

const KITTEN_VOICES = new Set([
  'Bella', 'Jasper', 'Luna', 'Bruno', 'Rosie', 'Hugo', 'Kiki', 'Leo',
])

export default async function handler(req, res) {
  // Require a valid session, consistent with the app's other endpoints.
  try { await requireAuth(req) }
  catch (err) {
    if (err?.cors) { setCORS(res, req); res.statusCode = 204; res.end(); return }
    sendError(res, err.status || 401, err.body?.error || 'Unauthorized')
    return
  }

  if (req.method === 'OPTIONS') { setCORS(res, req); res.statusCode = 204; res.end(); return }
  if (req.method !== 'POST') {
    setCORS(res, req); res.statusCode = 405
    res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ error: 'Method not allowed' }))
    return
  }

  const upstream = process.env.KITTEN_TTS_URL
  if (!upstream) {
    // Not configured → tell the client to fall back to browser TTS.
    sendError(res, 503, 'KittenTTS is not configured on the server.')
    return
  }

  let body
  try { body = await parseBody(req) }
  catch { sendError(res, 400, 'Invalid JSON body'); return }

  const text = String(body?.text || '').slice(0, 5000).trim()
  if (!text) { sendError(res, 400, 'text is required'); return }

  let voice = String(body?.voice || 'Jasper')
  if (!KITTEN_VOICES.has(voice)) voice = 'Jasper'
  let speed = Number(body?.speed)
  if (!Number.isFinite(speed) || speed <= 0) speed = 1.0
  speed = Math.min(Math.max(speed, 0.5), 2.0)

  try {
    const headers = { 'Content-Type': 'application/json', Accept: 'audio/wav, application/json' }
    if (process.env.KITTEN_TTS_KEY) headers.Authorization = `Bearer ${process.env.KITTEN_TTS_KEY}`

    const r = await fetch(upstream, {
      method: 'POST',
      headers,
      body: JSON.stringify({ text, voice, speed }),
    })

    if (!r.ok) {
      const detail = await r.text().catch(() => '')
      sendError(res, 502, `KittenTTS upstream error ${r.status}: ${detail.slice(0, 120)}`)
      return
    }

    const contentType = r.headers.get('content-type') || ''

    // Case B: JSON with base64 audio.
    if (contentType.includes('application/json')) {
      const data = await r.json().catch(() => ({}))
      const b64 = data?.audio || data?.audio_base64 || ''
      if (!b64) { sendError(res, 502, 'KittenTTS returned no audio.'); return }
      const buf = Buffer.from(b64, 'base64')
      setCORS(res, req)
      res.statusCode = 200
      res.setHeader('Content-Type', 'audio/wav')
      res.setHeader('Cache-Control', 'no-store')
      res.end(buf)
      return
    }

    // Case A: raw audio bytes.
    const arrayBuf = await r.arrayBuffer()
    const buf = Buffer.from(arrayBuf)
    setCORS(res, req)
    res.statusCode = 200
    res.setHeader('Content-Type', contentType.startsWith('audio/') ? contentType : 'audio/wav')
    res.setHeader('Cache-Control', 'no-store')
    res.end(buf)
  } catch (e) {
    sendError(res, 502, 'KittenTTS request failed: ' + (e?.message || 'unknown'))
  }
}

// POST /api/suggest  { messages, count? }  -> { suggestions: [{short, full}] }
// Generates context-aware reply suggestions based on the conversation.
// Returns 2-3 suggestions with a short display label and a full structured prompt.

import { requireAuth, setCORS, sendError, parseBody } from './_lib/auth.js'

const DEFAULT_BASE = 'https://integrate.api.nvidia.com/v1'
const SUGGEST_MODEL = 'google/gemma-3-27b-it'

const SYS = `You are a smart reply suggestion generator for an AI chat app called NRVS.
Given the conversation, suggest EXACTLY 3 follow-up messages the user might want to send next.

Each suggestion has two parts:
1. "short" — a punchy 2-6 word LABEL shown on a small chip (e.g. "Calculate trip expenses", "Basic Japanese phrases", "Draft the email"). No punctuation at the end. This is ALL the user sees on the button.
2. "full" — the COMPLETE, richly detailed prompt that is actually sent to NRVS when the chip is clicked. This must read like a thoughtful power-user typed it: pull in concrete context from the conversation (names, numbers, places, constraints already mentioned), then give NRVS clear, specific, well-organized instructions.

Rules for the "full" prompt:
- Make it genuinely detailed and actionable — typically 4-12 sentences, and use numbered or bulleted requirements when the task has multiple parts.
- Bake in the relevant specifics from the conversation so NRVS has everything it needs without asking follow-ups.
- Specify the desired output format when useful (e.g. a table, step-by-step plan, comparison, budget in specific currencies, ranges/tiers).
- Be concrete: prefer "estimate costs for budget / mid-range / comfortable travelers in INR and JPY" over "give me a budget".
- The 3 suggestions must be DIVERSE (different angles/next steps), never restating each other.
- NEVER suggest generic filler like "Tell me more", "Explain again", or "Continue".

Return STRICT JSON only, no prose, no code fences:
{"suggestions":[{"short":"...","full":"..."},{"short":"...","full":"..."},{"short":"...","full":"..."}]}`

export default async function handler(req, res) {
  try { await requireAuth(req) }
  catch (err) {
    if (err?.cors) { setCORS(res, req); res.statusCode = 204; res.end(); return }
    sendError(res, err.status || 401, err.body?.error || 'Unauthorized')
    return
  }
  if (req.method === 'OPTIONS') { setCORS(res, req); res.statusCode = 204; res.end(); return }
  if (req.method !== 'POST') {
    setCORS(res, req); res.statusCode = 405; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ error: 'Method not allowed' }))
    return
  }

  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ suggestions: [] }))
    return
  }

  let body
  try { body = await parseBody(req) }
  catch (e) {
    setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ suggestions: [] }))
    return
  }

  const messages = Array.isArray(body?.messages) ? body.messages : []
  if (!messages.length) {
    setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ suggestions: [] }))
    return
  }

  // Build a compact summary of the conversation
  const transcript = messages
    .slice(-10)
    .map((m) => `${m.role.toUpperCase()}: ${String(m.content || '').slice(0, 1500)}`)
    .join('\n')
    .slice(0, 6000)

  try {
    const baseURL = process.env.OPENAI_BASE_URL || DEFAULT_BASE
    const r = await fetch(`${baseURL}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: SUGGEST_MODEL,
        temperature: 0.8,
        max_tokens: 1200,
        messages: [
          { role: 'system', content: SYS },
          { role: 'user', content: `Here is the conversation so far:\n\n${transcript}\n\nSuggest 3 follow-up messages the user might want to send next.` },
        ],
      }),
    })
    if (!r.ok) {
      setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ suggestions: [] }))
      return
    }
    const data = await r.json()
    const content = data?.choices?.[0]?.message?.content || '{}'
    const parsed = parseSuggestions(content)
    setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ suggestions: parsed }))
  } catch {
    setCORS(res, req); res.statusCode = 200; res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ suggestions: [] }))
  }
}

function parseSuggestions(text) {
  try {
    const match = text.match(/\{[\s\S]*\}/)
    const obj = JSON.parse(match ? match[0] : text)
    if (Array.isArray(obj.suggestions)) {
      return obj.suggestions
        .filter((s) => s.short && s.full)
        .map((s) => ({ short: String(s.short).slice(0, 60), full: String(s.full).slice(0, 2500) }))
        .slice(0, 3)
    }
  } catch { /* ignore */ }
  return []
}

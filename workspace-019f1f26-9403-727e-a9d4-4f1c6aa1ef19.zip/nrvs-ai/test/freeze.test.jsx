import { describe, it, expect, beforeEach, vi } from 'vitest'
import React from 'react'
import { render, act, cleanup } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'

// Real store + real Message component (the actual render path)
import {
  createThread, addMessage, getThread,
  updateMessage, setMessageTools, finalizeMessage,
  useThread,
} from '../src/lib/store.js'
import Message from '../src/components/Message.jsx'
import { ArtifactProvider } from '../src/lib/artifacts.jsx'

// jsdom lacks these; stub so components mount.
beforeEach(() => {
  cleanup()
  if (!window.matchMedia) {
    window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} })
  }
  Element.prototype.scrollIntoView = () => {}
  if (!navigator.clipboard) navigator.clipboard = { writeText: async () => {} }
})

// A minimal mirror of Thread.jsx's message list, wired to the real store.
let renderCount = 0
function ThreadView({ id, busy }) {
  renderCount++
  const thread = useThread(id)
  const messages = thread?.messages || []
  return (
    <div>
      {messages.map((m, idx) => {
        const isLast = idx === messages.length - 1
        return (
          <Message
            key={m.id}
            role={m.role}
            content={m.content}
            model={m.model}
            tools={m.tools}
            threadId={id}
            msgId={m.id}
            streaming={busy && isLast && m.role === 'assistant'}
          />
        )
      })}
    </div>
  )
}

function mount(id) {
  return render(
    <MemoryRouter>
      <ArtifactProvider>
        <ThreadView id={id} busy={true} />
      </ArtifactProvider>
    </MemoryRouter>
  )
}

// Simulate one streamed assistant turn the way useChat does (throttled flushes).
async function streamTurn(threadId, assistantId, chunks) {
  let acc = ''
  for (const c of chunks) {
    acc += c
    await act(async () => {
      updateMessage(threadId, assistantId, acc)
      // let React flush
      await Promise.resolve()
    })
  }
  await act(async () => {
    finalizeMessage(threadId, assistantId, acc)
    await Promise.resolve()
  })
  return acc
}

describe('page freeze repro — two consecutive requests', () => {
  it('does not throw hook errors and does not runaway-render on the 2nd request', async () => {
    const errors = []
    const origErr = console.error
    console.error = (...a) => { errors.push(a.join(' ')); }

    const threadId = await createThread('Hello')

    // ---- Request #1 ----
    await addMessage(threadId, { role: 'user', content: 'Hello' })
    const a1 = await addMessage(threadId, { role: 'assistant', content: '', model: 'meta/llama-3.1-8b-instruct' })

    let view
    await act(async () => { view = mount(threadId) })
    renderCount = 0

    await streamTurn(threadId, a1, ['Hi', ' there', '! Here', ' is **bold**', ' and `code`.'])
    const rendersReq1 = renderCount

    // ---- Request #2 (the reported freeze trigger) ----
    renderCount = 0
    await act(async () => {
      view.rerender(
        <MemoryRouter>
          <ArtifactProvider>
            <ThreadView id={threadId} busy={true} />
          </ArtifactProvider>
        </MemoryRouter>
      )
    })
    await addMessage(threadId, { role: 'user', content: 'Second question' })
    const a2 = await addMessage(threadId, { role: 'assistant', content: '', model: 'meta/llama-3.1-8b-instruct' })

    await streamTurn(threadId, a2, ['Sure', ', more ', 'text ', 'here ', 'again.'])
    const rendersReq2 = renderCount

    console.error = origErr

    const hookErrors = errors.filter(e => /hook|Rendered more hooks|Maximum update depth/i.test(e))
    console.log('renders req1:', rendersReq1, 'renders req2:', rendersReq2)
    console.log('hookErrors:', hookErrors.length, hookErrors.slice(0, 2))

    expect(hookErrors, 'React hook / update-depth errors: ' + JSON.stringify(hookErrors.slice(0,3))).toEqual([])
    // A runaway loop would produce hundreds/thousands of renders for ~5 chunks.
    expect(rendersReq2, 'render count exploded on 2nd request').toBeLessThan(60)

    const t = getThread(threadId)
    expect(t.messages.length).toBe(4)
    expect(t.messages[3].content).toContain('again')
  })
})

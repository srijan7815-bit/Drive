import { it, expect, beforeEach, vi } from 'vitest'
import React from 'react'
import { render, act, cleanup, fireEvent } from '@testing-library/react'

beforeEach(() => {
  cleanup()
  Element.prototype.scrollIntoView = () => {}
  if (!navigator.clipboard) navigator.clipboard = { writeText: async () => {} }
})

it('suggestions store: stable snapshot, loading->ready, token supersession', async () => {
  const store = await import('../src/lib/suggestions.js')
  const id = 't1'

  // Stable identity when idle
  const a = store.useSuggestions // hook exists
  expect(typeof a).toBe('function')

  // begin -> loading
  const tok1 = store.beginSuggestions(id)
  // an older token cannot commit after a newer begin
  const tok2 = store.beginSuggestions(id)
  store.setSuggestions(id, tok1, [{ short: 'stale', full: 'stale full' }]) // should be ignored
  store.setSuggestions(id, tok2, [{ short: 'Calculate trip', full: 'Calculate the estimated expenses...' }])

  // Read via a component
  let seen = null
  function Probe() { seen = store.useSuggestions(id); return null }
  await act(async () => { render(<Probe/>) })
  expect(seen.status).toBe('ready')
  expect(seen.items.length).toBe(1)
  expect(seen.items[0].short).toBe('Calculate trip')
  expect(seen.items[0].full).toContain('estimated expenses')

  // clear
  await act(async () => { store.clearSuggestions(id) })
  expect(store.useSuggestions.length).toBeGreaterThanOrEqual(0)
})

it('ReplySuggestions: renders chips, click sends FULL prompt; no double render loop', async () => {
  const ReplySuggestions = (await import('../src/components/ReplySuggestions.jsx')).default
  const picked = []
  const onPick = (s) => picked.push(s)
  const suggestions = [
    { short: 'Calculate trip expenses', full: 'FULL DETAILED PROMPT about Japan trip budget...' },
    { short: 'Basic Japanese phrases', full: 'Teach me basic Japanese phrases for travel...' },
  ]
  let commits = 0
  const onRender = () => { commits++; if (commits > 200) throw new Error('LOOP ' + commits) }
  const { getByText } = render(
    <React.Profiler id="p" onRender={onRender}>
      <ReplySuggestions suggestions={suggestions} onPick={onPick} loading={false} />
    </React.Profiler>
  )
  fireEvent.click(getByText('Calculate trip expenses'))
  expect(picked.length).toBe(1)
  expect(picked[0].full).toContain('FULL DETAILED PROMPT')
})

it('ContinueButton: click invokes handler (awaits async)', async () => {
  const ContinueButton = (await import('../src/components/ContinueButton.jsx')).default
  let called = 0
  const onClick = async () => { called++ }
  const { getByText } = render(<ContinueButton onClick={onClick} />)
  await act(async () => { fireEvent.click(getByText(/Continue response/i)) })
  expect(called).toBe(1)
})

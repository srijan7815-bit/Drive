import { describe, it, expect, beforeEach } from 'vitest'
import React from 'react'
import { render, act, cleanup } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'

beforeEach(() => {
  cleanup()
  Element.prototype.scrollIntoView = () => {}
  if (!navigator.clipboard) navigator.clipboard = { writeText: async () => {} }
})

it('streaming Message: update then finalize does not loop', async () => {
  const Message = (await import('../src/components/Message.jsx')).default
  const { ArtifactProvider } = await import('../src/lib/artifacts.jsx')
  const store = await import('../src/lib/store.js')

  let sawLoop = false
  const orig = console.error
  console.error = (...a) => { if (/Maximum update depth|too many re-renders/i.test(a.join(' '))) sawLoop = true; }

  const msgId = 'stream-1'
  await act(async () => {
    render(
      <MemoryRouter><ArtifactProvider>
        <Message role="assistant" content="" msgId={msgId} threadId="t1" streaming={true} />
      </ArtifactProvider></MemoryRouter>
    )
  })
  console.log('mounted streaming ok')

  for (const c of ['Hello',' world',' **bold**']) {
    await act(async () => { store.updateMessage('t1', msgId, (store.getStreamingContent(msgId)||'') + c); await Promise.resolve() })
  }
  console.log('streamed ok')
  await act(async () => { store.finalizeMessage('t1', msgId, 'Hello world **bold**'); await Promise.resolve() })
  console.log('finalized ok')

  console.error = orig
  expect(sawLoop).toBe(false)
}, 8000)

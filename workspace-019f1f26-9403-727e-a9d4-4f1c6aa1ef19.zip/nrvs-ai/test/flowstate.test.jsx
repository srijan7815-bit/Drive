import { it, expect } from 'vitest'

// Progress math mirrors MissionControl's computation. We test the FORMULA to
// lock in that research + documents + tasks all count toward progress.
function progress(m) {
  const tasks = m.tasks || []
  const research = m.research || []
  const documents = m.documents || []
  const doneTasks = tasks.filter((t) => t.status === 'done').length
  const doneResearch = research.filter((r) => r.done || r.result).length
  const doneDocs = documents.filter((d) => d.done || d.content).length
  const totalItems = tasks.length + research.length + documents.length
  const doneItems = doneTasks + doneResearch + doneDocs
  return { totalItems, doneItems, pct: totalItems ? Math.round((doneItems / totalItems) * 100) : 0 }
}

// Executable check mirrors useFlowLauncher's validation.
function executable(m) {
  return (m?.research?.length || 0) + (m?.documents?.length || 0) + (m?.tasks?.length || 0)
}

it('progress counts research + documents + tasks', () => {
  const m = {
    tasks: [{ status: 'done' }, { status: 'todo' }],
    research: [{ done: true }, { result: 'x' }, { note: 'pending' }],
    documents: [{ content: 'written' }, {}],
  }
  const p = progress(m)
  expect(p.totalItems).toBe(7)          // 2 + 3 + 2
  expect(p.doneItems).toBe(4)           // 1 task + 2 research + 1 doc
  expect(p.pct).toBe(57)                // round(4/7*100)
})

it('research/document-only mission is now considered executable (was rejected before)', () => {
  const researchOnly = { research: [{ topic: 'a' }, { topic: 'b' }], documents: [], tasks: [] }
  expect(executable(researchOnly)).toBe(2)   // > 0 -> valid
  const docOnly = { research: [], documents: [{ name: 'Report' }], tasks: [] }
  expect(executable(docOnly)).toBe(1)        // > 0 -> valid
})

it('roadmap/timeline-only mission (nothing to run) is correctly rejected', () => {
  const planOnly = { roadmap: [{}], timeline: [{}, {}], research: [], documents: [], tasks: [] }
  expect(executable(planOnly)).toBe(0)       // 0 -> rejected (no runnable items)
})

it('parseMissionText preserves research/documents fields the runner needs', async () => {
  const { generateMission } = await import('../src/lib/flows.js')
  expect(typeof generateMission).toBe('function')
})

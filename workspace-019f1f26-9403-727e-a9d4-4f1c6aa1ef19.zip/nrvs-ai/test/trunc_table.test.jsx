import { it, expect } from 'vitest'
it('looksTruncated flags a cut-off table row', async () => {
  const { looksTruncated } = await import('../src/lib/markdown.jsx')
  const cut = `| Item | Cost |
|---|---|
| Flights | 50000 |
| Hotel | 300`
  expect(looksTruncated(cut)).toBe(true)
  // complete table should NOT be flagged
  const full = `| Item | Cost |
|---|---|
| Flights | 50000 |
| Hotel | 30000 |

Done.`
  expect(looksTruncated(full)).toBe(false)
})

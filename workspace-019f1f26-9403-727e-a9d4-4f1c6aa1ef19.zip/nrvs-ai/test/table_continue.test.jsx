import { it, expect, beforeEach } from 'vitest'
import React from 'react'
import { renderToString } from 'react-dom/server'

beforeEach(() => {})

it('Markdown table: ALL body rows render inside the table (not spilled as text)', async () => {
  const Markdown = (await import('../src/lib/markdown.jsx')).default
  const md = `Here is your budget:

| Item | Cost (INR) |
|---|---|
| Flights | 50000 |
| Hotel | 30000 |
| Food | 15000 |

That is the total.`
  const html = renderToString(React.createElement(Markdown, { text: md }))
  // All three data values must appear inside <td> cells
  expect(html).toContain('<table')
  for (const v of ['Flights', 'Hotel', 'Food', '50000', '30000', '15000']) {
    expect(html, `${v} should be in the table`).toContain(v)
  }
  // The table cells should be <td>, and none of Hotel/Food should leak as a
  // stray "| Hotel | 30000 |" text line (which was the bug).
  expect(html).not.toContain('| Hotel |')
  expect(html).not.toContain('| Food |')
})

it('Markdown table at end of string (no trailing newline) renders fully', async () => {
  const Markdown = (await import('../src/lib/markdown.jsx')).default
  const md = `| A | B |\n|--|--|\n| 1 | 2 |\n| 3 | 4 |`
  const html = renderToString(React.createElement(Markdown, { text: md }))
  for (const v of ['1', '2', '3', '4']) expect(html).toContain(v)
  expect(html).not.toContain('| 3 |')
})

it('finalizeMessage records truncated flag; drives Continue across continuations', async () => {
  const store = await import('../src/lib/store.js')
  const tid = await store.createThread('t')
  const mid = await store.addMessage(tid, { role: 'assistant', content: '' })
  // First finalize: truncated
  store.finalizeMessage(tid, mid, 'The total is', { truncated: true })
  let msg = store.getThread(tid).messages.find(m => m.id === mid)
  expect(msg.truncated).toBe(true)
  // Continuation also truncated -> new message flagged truncated too
  const mid2 = await store.addMessage(tid, { role: 'assistant', content: '' })
  store.finalizeMessage(tid, mid2, 'and then', { truncated: true })
  let msg2 = store.getThread(tid).messages.find(m => m.id === mid2)
  expect(msg2.truncated).toBe(true)
  // Final continuation completes -> not truncated
  const mid3 = await store.addMessage(tid, { role: 'assistant', content: '' })
  store.finalizeMessage(tid, mid3, 'the answer is 42.', { truncated: false })
  let msg3 = store.getThread(tid).messages.find(m => m.id === mid3)
  expect(msg3.truncated).toBe(false)
})

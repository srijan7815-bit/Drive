import { it, expect, beforeEach, vi } from 'vitest'

beforeEach(() => {
  vi.restoreAllMocks()
  // minimal browser TTS mock
  global.window = global.window || {}
  const spoken = []
  window.speechSynthesis = {
    speaking: false,
    cancel: () => {},
    speak: (u) => { spoken.push(u); if (u.onend) setTimeout(() => u.onend(), 0) },
  }
  global.SpeechSynthesisUtterance = class { constructor(t){ this.text=t } }
  window.__spoken = spoken
})

it('cleanForSpeech strips markdown', async () => {
  const { cleanForSpeech } = await import('../src/lib/tts.js')
  expect(cleanForSpeech('**bold** and `code` and [link](http://x)')).toBe('bold and code and link')
  expect(cleanForSpeech('```js\nconst x=1\n```')).toContain('code block')
  expect(cleanForSpeech('')).toBe('')
})

it('KITTEN_VOICES has the 8 documented voices', async () => {
  const { KITTEN_VOICES } = await import('../src/lib/tts.js')
  expect(KITTEN_VOICES).toEqual(['Bella','Jasper','Luna','Bruno','Rosie','Hugo','Kiki','Leo'])
})

it('speak falls back to browser TTS when /api/tts fails (no throw)', async () => {
  // fetch fails => Kitten path errors => should fall back to browser speak.
  global.fetch = vi.fn(async () => { throw new Error('network') })
  const { speak } = await import('../src/lib/tts.js')
  let ended = false
  await speak('Hello world', { engine: 'auto', voice: 'Jasper', onend: () => { ended = true } })
  // browser speak was invoked
  expect(window.__spoken.length).toBe(1)
  expect(window.__spoken[0].text).toBe('Hello world')
})

it('engine=browser never calls the network', async () => {
  const fetchSpy = vi.fn(async () => { throw new Error('should not be called') })
  global.fetch = fetchSpy
  const { speak } = await import('../src/lib/tts.js')
  await speak('Hi there', { engine: 'browser' })
  expect(fetchSpy).not.toHaveBeenCalled()
  expect(window.__spoken.length).toBe(1)
})

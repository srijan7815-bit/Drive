import {
  MessageCircle,
  Library,
  FolderOpen,
  LayoutGrid,
  Brain,
} from 'lucide-react'
import Hamsa from './icons/Hamsa.jsx'

/**
 * Primary sidebar nav.
 * Per spec: rename "Chat" -> "Thread", and add "Library" between Thread and Projects.
 * Order: Thread, Library, Projects, Artifacts.
 */
export const navItems = [
  { id: 'thread', label: 'Thread', icon: MessageCircle, to: '/' },
  { id: 'flows', label: 'Flow State', icon: Hamsa, to: '/flows' },
  { id: 'library', label: 'Library', icon: Library, to: '/library' },
  { id: 'projects', label: 'Projects', icon: FolderOpen, to: '/projects' },
  { id: 'artifacts', label: 'Artifacts', icon: LayoutGrid, to: '/artifacts' },
  { id: 'memory', label: 'Memory', icon: Brain, to: '/memory' },
]

export const MODEL_NAME = 'Sonnet 4.6'
export const USER_NAME = 'Bachira'
export const USER_INITIAL = 'B'

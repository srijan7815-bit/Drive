// Hamsa (protective hand with an all-seeing eye) — original inline SVG icon.
//
// Drawn from scratch to match the lucide-react API and stroke style used by the
// rest of the app's nav icons, so it accepts `size`, `strokeWidth`, `color`,
// and `className` props and inherits the current text color via `currentColor`.
// Being original artwork (not a downloaded Flaticon asset), it needs no
// attribution and renders inline (works in the sandboxed preview).
export default function Hamsa({
  size = 18,
  strokeWidth = 1.6,
  color = 'currentColor',
  className,
  ...props
}) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      {...props}
    >
      {/* Palm sides + rounded base */}
      <path d="M6 13v1.5C6 18 8.4 20.5 12 20.5S18 18 18 14.5V13" />
      {/* Middle finger (tallest, centered) */}
      <path d="M10.9 12V4.3a1.1 1.1 0 0 1 2.2 0V12" />
      {/* Left inner finger */}
      <path d="M7.9 12V7a1.1 1.1 0 0 1 2.2 0v5" />
      {/* Right inner finger */}
      <path d="M13.9 12V7a1.1 1.1 0 0 1 2.2 0v5" />
      {/* Left thumb */}
      <path d="M6 13.2V10a1.05 1.05 0 0 0-1.9-.5" />
      {/* Right thumb */}
      <path d="M18 13.2V10a1.05 1.05 0 0 1 1.9-.5" />
      {/* All-seeing eye in the palm */}
      <path d="M9.7 15.6c.6-1 1.4-1.5 2.3-1.5s1.7.5 2.3 1.5c-.6 1-1.4 1.5-2.3 1.5s-1.7-.5-2.3-1.5Z" />
      <circle cx="12" cy="15.6" r="0.65" fill={color} stroke="none" />
    </svg>
  )
}

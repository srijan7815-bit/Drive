import { NavLink, useLocation, useNavigate, useParams } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { navItems, USER_INITIAL } from './nav'
import { useThreads, deleteThread } from '../lib/store'
import Wordmark from './Wordmark'
import { useAuth } from '../lib/auth'
import { useProfile } from '../lib/profile'
import { useConfirm } from '../lib/useConfirm'

/**
 * Shared sidebar body used by both the desktop fixed sidebar and the mobile overlay.
 * Brand, nav list, real Recents (persisted threads), user avatar + "New thread".
 *
 * When `collapsed` is true, shows only icons (no text labels, no Recents list).
 */
export default function SidebarContent({ onNavigate, collapsed = false }) {
  const location = useLocation()
  const navigate = useNavigate()
  const params = useParams()
  const threads = useThreads()
  const { user } = useAuth()
  const { name } = useProfile()
  const initial = (name || user?.email || USER_INITIAL).charAt(0).toUpperCase()
  const [confirm, confirmUI] = useConfirm()

  const legalLinks = [
    { label: 'Privacy', to: '/privacy' },
    { label: 'Terms', to: '/terms' },
    { label: 'Cookies', to: '/cookies' },
  ]

  const askDelete = async (t) => {
    const ok = await confirm({
      title: 'Delete thread?',
      message: `"${t.title}" will be permanently deleted.`,
      confirmLabel: 'Delete',
    })
    if (ok) {
      deleteThread(t.id)
      if (params.id === t.id) go('/')
    }
  }

  const go = (to) => {
    navigate(to)
    onNavigate?.()
  }

  // ── Collapsed mode: icon-only rail ──
  if (collapsed) {
    return (
      <div className="flex h-full flex-col items-center pt-5">
        {/* Brand — hand icon */}
        <button
          onClick={() => go('/')}
          aria-label="NRVS home"
          className="mb-4 mt-1 invert"
        >
          <img
            src="/apple-touch-icon.png"
            alt="NRVS"
            className="h-8 w-8"
          />
        </button>

        {/* Nav icons */}
        <nav className="flex flex-col items-center gap-1 px-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const active =
              item.to === '/'
                ? location.pathname === '/' || location.pathname.startsWith('/thread')
                : location.pathname.startsWith(item.to)
            return (
              <NavLink
                key={item.id}
                to={item.to}
                onClick={onNavigate}
                title={item.label}
                className={`flex h-9 w-9 items-center justify-center rounded-md transition-colors duration-200 ${
                  active
                    ? 'bg-surface2 text-text-primary'
                    : 'text-text-tertiary hover:bg-border hover:text-text-secondary'
                }`}
              >
                <Icon size={18} strokeWidth={1.75} />
              </NavLink>
            )
          })}
        </nav>

        {/* Spacer */}
        <div className="flex-1" />

        {/* New thread button */}
        <button
          onClick={() => go('/')}
          title="New thread"
          className="mb-3 flex h-9 w-9 items-center justify-center rounded-md text-text-tertiary transition-colors hover:bg-surface2 hover:text-text-secondary"
        >
          <Plus size={18} strokeWidth={2} />
        </button>

        {/* Avatar */}
        <button
          onClick={() => go('/settings')}
          title="Settings"
          className="mb-3 flex h-8 w-8 items-center justify-center rounded-pill bg-surface2 text-xs font-medium text-text-primary ring-1 ring-border"
        >
          {initial}
        </button>

        {confirmUI}
      </div>
    )
  }

  // ── Expanded mode: full sidebar ──
  return (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className="px-4 pt-5 pb-3">
        <button onClick={() => go('/')} aria-label="NRVS home">
          <Wordmark className="text-2xl" />
        </button>
      </div>

      {/* Nav */}
      <nav className="px-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const active =
            item.to === '/'
              ? location.pathname === '/' || location.pathname.startsWith('/thread')
              : location.pathname.startsWith(item.to)
          return (
            <NavLink
              key={item.id}
              to={item.to}
              onClick={onNavigate}
              className={`nav-row ${active ? 'active' : ''}`}
            >
              <Icon size={18} strokeWidth={1.75} className="shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          )
        })}
      </nav>

      {/* Recents (real persisted threads) */}
      <div className="mt-4 flex-1 overflow-y-auto px-2">
        <div className="mb-1 px-3 text-caption font-medium uppercase tracking-wide text-text-tertiary">
          Recents
        </div>
        {threads.length === 0 ? (
          <p className="px-3 py-2 text-body-sm text-text-tertiary">
            No threads yet. Start a new one.
          </p>
        ) : (
          <div className="space-y-0.5">
            {threads.map((t) => {
              const active = params.id === t.id
              return (
                <div
                  key={t.id}
                  className={`group flex items-center gap-1 rounded-sm pr-1 transition-colors duration-200 ${
                    active ? 'bg-surface2' : 'hover:bg-border'
                  }`}
                >
                  <button
                    onClick={() => go(`/thread/${t.id}`)}
                    className={`flex min-w-0 flex-1 items-center gap-1.5 px-3 py-2 text-left text-body-sm ${
                      active ? 'text-text-primary' : 'text-text-secondary'
                    }`}
                    title={t.title}
                  >
                    <span className="min-w-0 flex-1 truncate">{t.title}</span>
                    {t.shared && (
                      <span className="shrink-0 rounded-pill border border-border bg-surface2 px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-text-tertiary">
                        Shared
                      </span>
                    )}
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      askDelete(t)
                    }}
                    className="hidden h-7 w-7 shrink-0 items-center justify-center rounded-sm text-text-tertiary hover:text-danger group-hover:flex"
                    aria-label="Delete thread"
                  >
                    <Trash2 size={14} strokeWidth={1.75} />
                  </button>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Legal links */}
      <div className="mt-3 flex items-center justify-center gap-3 px-3 border-t border-border pt-3">
        {legalLinks.map((link) => (
          <a
            key={link.to}
            href={link.to}
            onClick={onNavigate}
            className="text-caption text-text-tertiary transition-colors hover:text-text-secondary"
          >
            {link.label}
          </a>
        ))}
      </div>

      {/* Bottom: avatar (settings) + new thread */}
      <div className="mt-auto flex items-center gap-3 border-t border-border px-3 py-3">
        <button
          onClick={() => go('/settings')}
          aria-label="Open settings"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-pill bg-surface2 text-body-sm font-medium text-text-primary ring-1 ring-border transition-colors duration-200 hover:bg-border"
        >
          {initial}
        </button>
        <button
          onClick={() => go('/')}
          className="btn-primary h-9 flex-1 px-4 text-body-sm"
        >
          <Plus size={16} strokeWidth={2} />
          New thread
        </button>
      </div>
      {confirmUI}
    </div>
  )
}

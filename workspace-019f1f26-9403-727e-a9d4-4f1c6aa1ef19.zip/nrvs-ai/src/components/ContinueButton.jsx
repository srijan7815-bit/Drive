import { useState } from 'react'
import { motion } from 'framer-motion'
import { FastForward, Loader2 } from 'lucide-react'
import { haptic } from '../lib/haptics'

/**
 * "Continue" — shown, right-aligned, when the last assistant response was
 * received incomplete (cut off by the model's token limit). Clicking it asks
 * NRVS to continue exactly from where it stopped.
 *
 * Reliability fix: the click is guarded with a local "sending" state so a
 * double-tap can't fire two continuations, and we always call the handler even
 * if it's async (awaited) — previously the button could feel unresponsive if
 * the underlying request threw before any UI feedback.
 */
export default function ContinueButton({ onClick }) {
  const [sending, setSending] = useState(false)

  const handle = async () => {
    if (sending) return
    haptic('light')
    setSending(true)
    try {
      await onClick?.()
    } finally {
      // The button typically unmounts once generation starts (the response is
      // no longer "truncated"), but reset defensively in case it stays mounted.
      setSending(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="mt-3 flex flex-col items-end"
    >
      <button
        type="button"
        onClick={handle}
        disabled={sending}
        className="flex items-center gap-2 rounded-pill border border-accent-orange/40 bg-accent-orange/10 px-4 py-2 text-body-sm text-accent-orange transition-colors hover:bg-accent-orange/20 disabled:opacity-60"
      >
        {sending ? (
          <Loader2 size={14} className="animate-spin" />
        ) : (
          <FastForward size={14} />
        )}
        {sending ? 'Continuing…' : 'Continue response'}
      </button>
      <p className="mt-1.5 text-right text-caption text-text-tertiary">
        Response was cut off. Click to continue from where it stopped.
      </p>
    </motion.div>
  )
}

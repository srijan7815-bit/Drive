import { useState } from 'react'
import { motion } from 'framer-motion'
import { Volume2, VolumeX, Copy, Check, Brain, AppWindow, BookmarkPlus, Pencil, RefreshCw, X } from 'lucide-react'
import Markdown from '../lib/markdown.jsx'
import ToolChips from './ToolChips'
import { modelLabel } from '../lib/models'
import { speak, stopSpeaking, ttsSupported, isSpeaking } from '../lib/speech'
import { usePrefs } from '../lib/prefs'
import MemoryPopup from './MemoryPopup'
import { parseCodeBlocks, compileArtifact, useArtifacts } from '../lib/artifacts'
import { saveToLibrary } from '../lib/library'
import { haptic } from '../lib/haptics'
import { useProfile } from '../lib/profile'
import { useStreamingContent } from '../lib/store'

export default function Message({
  role,
  content,
  image,
  model,
  tools,
  streaming,
  shared,
  threadId,
  msgId,
  onEdit,
  onRetry,
}) {
  const isUser = role === 'user'

  // During streaming, use the lightweight per-message subscription
  // instead of the full store content — prevents re-rendering ALL messages.
  const streamingData = useStreamingContent(msgId)
  const displayContent = streaming ? (streamingData.content ?? content) : content
  const displayTools = streaming ? (streamingData.tools ?? tools) : tools
  const { name } = useProfile()
  const [prefs] = usePrefs()
  const [speaking, setSpeaking] = useState(false)
  const [copied, setCopied] = useState(false)
  const [saved, setSaved] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(content)
  const { openArtifact } = useArtifacts()

  const blocks = !isUser ? parseCodeBlocks(displayContent) : []
  const hasPreviewable = blocks.some((b) =>
    ['html', 'htm', 'css', 'js', 'javascript', 'svg'].includes(
      (b.language || '').toLowerCase()
    )
  )

  const onSpeak = () => {
    if (speaking) {
      stopSpeaking()
      setSpeaking(false)
      return
    }
    speak(content, {
      engine: prefs.ttsEngine,
      voice: prefs.ttsVoice,
      onend: () => setSpeaking(false),
    })
    setSpeaking(true)
    // Safety poll: also clear the speaking state if playback ends without
    // firing onend (covers both browser speechSynthesis and Kitten <audio>).
    const t = setInterval(() => {
      if (!isSpeaking()) {
        setSpeaking(false)
        clearInterval(t)
      }
    }, 400)
  }

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(content)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      /* ignore */
    }
  }

  const fileCount = blocks.filter((b) => b.filename).length
  const artifactTitle = () => {
    const named = blocks.find((b) => b.filename)?.filename
    if (fileCount > 1) return `Project (${blocks.length} files)`
    return named || 'Preview'
  }

  const onOpenArtifact = () => {
    openArtifact({
      type: 'html',
      title: artifactTitle(),
      content: compileArtifact(blocks),
      files: blocks.map((b, i) => ({
        name: b.filename || `${b.language || 'file'}-${i + 1}`,
        language: b.language,
        code: b.code,
      })),
    })
  }

  const onSaveLibrary = async () => {
    haptic('success')
    await saveToLibrary({
      title: artifactTitle(),
      kind: 'html',
      content: compileArtifact(blocks),
      threadId,
    })
    setSaved(true)
    setTimeout(() => setSaved(false), 1800)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
      className={`flex w-full items-end gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {/* Assistant content: bubble + actions wrapped in one column so actions don't affect bubble width */}
      {isUser && (
        <div className="max-w-[80%]">
          {/* Bubble */}
          <div className="w-fit">
            {editing ? (
              <div className="rounded-lg border border-border bg-surface2 p-2">
                <textarea
                  autoFocus
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  rows={Math.min(8, (draft.match(/\n/g)?.length || 0) + 2)}
                  className="w-full resize-none bg-transparent px-2 py-1 text-body text-text-primary focus:outline-none"
                />
                <div className="mt-1 flex justify-end gap-2">
                  <button
                    onClick={() => {
                      setDraft(content)
                      setEditing(false)
                    }}
                    className="flex items-center gap-1 rounded-pill px-3 py-1.5 text-body-sm text-text-tertiary hover:bg-border"
                  >
                    <X size={14} /> Cancel
                  </button>
                  <button
                    onClick={() => {
                      const next = draft.trim()
                      setEditing(false)
                      if (next && next !== content) onEdit?.(next)
                    }}
                    className="btn-primary h-8 px-4 text-body-sm"
                  >
                    Send
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-lg rounded-tr-sm border border-border bg-surface2 px-4 py-2.5 text-body text-text-primary">
                {image && (
                  <img
                    src={image}
                    alt="attachment"
                    className="mb-2 max-h-56 rounded-md border border-border object-contain"
                  />
                )}
                {content && <span className="whitespace-pre-wrap">{content}</span>}
              </div>
            )}
          </div>

          {/* Actions — inside the column, full-width, right-aligned */}
          {!shared && !editing && (
            <div className="mt-1 flex justify-end gap-1">
              <button
                onClick={onCopy}
                className="flex items-center gap-1 rounded-sm px-1.5 py-1 text-caption text-text-tertiary transition-colors hover:bg-border hover:text-text-primary"
                title="Copy"
              >
                {copied ? <Check size={13} /> : <Copy size={13} />}
              </button>
              {onEdit && (
                <button
                  onClick={() => {
                    setDraft(content)
                    setEditing(true)
                  }}
                  className="flex items-center gap-1 rounded-sm px-1.5 py-1 text-caption text-text-tertiary transition-colors hover:bg-border hover:text-text-primary"
                  title="Edit &amp; resend"
                >
                  <Pencil size={13} />
                </button>
              )}
              <div className="relative">
                <MemoryPopup content={content}>
                  <Brain size={13} />
                </MemoryPopup>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Assistant content */}
      {!isUser && (
        <div className="max-w-[85%] pt-1">
          {model && (
            <div className="mb-1 text-caption text-text-tertiary">
              {modelLabel(model)}
            </div>
          )}
          <ToolChips tools={displayTools} />
          <Markdown text={displayContent} />
          {streaming && (
            <span className="ml-0.5 inline-block h-4 w-1.5 animate-pulse rounded-sm bg-text-tertiary align-middle" />
          )}

          {!streaming && displayContent && !shared && (
            <div className="mt-2 flex items-center gap-1">
              <button
                onClick={onCopy}
                className="flex h-7 w-7 items-center justify-center rounded-sm text-text-tertiary transition-colors hover:bg-border hover:text-text-primary"
                title="Copy"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
              </button>
              {ttsSupported() && (
                <button
                  onClick={onSpeak}
                  className={`flex h-7 w-7 items-center justify-center rounded-sm transition-colors hover:bg-border ${
                    speaking
                      ? 'text-accent-blue'
                      : 'text-text-tertiary hover:text-text-primary'
                  }`}
                  title="Read aloud"
                >
                  {speaking ? <VolumeX size={14} /> : <Volume2 size={14} />}
                </button>
              )}
              <div className="relative">
                <MemoryPopup content={content}>
                  <Brain size={14} />
                </MemoryPopup>
              </div>
              {onRetry && (
                <button
                  onClick={onRetry}
                  className="flex h-7 w-7 items-center justify-center rounded-sm text-text-tertiary transition-colors hover:bg-border hover:text-text-primary"
                  title="Retry / regenerate"
                >
                  <RefreshCw size={14} />
                </button>
              )}
            </div>
          )}

          {/* Artifact footer */}
          {!streaming && hasPreviewable && !shared && (
            <div className="mt-2 overflow-hidden rounded-md border border-border bg-surface2">
              <button
                onClick={onOpenArtifact}
                className="flex w-full items-center gap-2 px-3 py-2.5 text-left transition-colors hover:bg-border"
              >
                <AppWindow size={16} className="text-accent-orange" />
                <span className="flex-1 text-body-sm text-text-primary">
                  Open compiled preview
                </span>
                <span className="text-caption text-text-tertiary">
                  {fileCount > 1 ? `${blocks.length} files →` : 'Artifact →'}
                </span>
              </button>
              <button
                onClick={onSaveLibrary}
                className="flex w-full items-center gap-2 border-t border-border px-3 py-2.5 text-left transition-colors hover:bg-border"
              >
                {saved ? (
                  <Check size={16} className="text-accent-blue" />
                ) : (
                  <BookmarkPlus size={16} className="text-text-secondary" />
                )}
                <span className="flex-1 text-body-sm text-text-primary">
                  {saved ? 'Saved to Library' : 'Save to Library'}
                </span>
              </button>
            </div>
          )}
          {!streaming && hasPreviewable && shared && (
            <button
              onClick={onOpenArtifact}
              className="mt-2 flex w-full items-center gap-2 rounded-md border border-border bg-surface2 px-3 py-2.5 text-left transition-colors hover:bg-border"
            >
              <AppWindow size={16} className="text-accent-orange" />
              <span className="flex-1 text-body-sm text-text-primary">
                Open compiled preview
              </span>
            </button>
          )}
        </div>
      )}

    </motion.div>
  )
}
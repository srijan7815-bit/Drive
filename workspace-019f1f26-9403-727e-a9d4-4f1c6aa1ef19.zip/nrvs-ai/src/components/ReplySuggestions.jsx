import { motion, AnimatePresence } from 'framer-motion'
import { MessageSquarePlus, Sparkles } from 'lucide-react'
import { haptic } from '../lib/haptics'

/**
 * Suggested Replies — right-aligned under the last assistant message.
 *
 * Each suggestion shows a SHORT punchy label (e.g. "Calculate trip expenses")
 * but sends the FULL detailed prompt when clicked (handled by the parent's
 * onPick, which passes suggestion.full to the model).
 *
 * Layout: the whole block is right-aligned (items-end) so it sits toward the
 * user's side of the conversation, as requested. Chips wrap and align right.
 *
 * Reliability: this component is purely presentational. The suggestions live in
 * a thread-scoped external store (see lib/suggestions.js), so they no longer
 * flicker or vanish on re-render. We render EITHER the loading skeleton OR the
 * chips — never both in the same frame — which also removes the flash.
 */
export default function ReplySuggestions({ suggestions, onPick, loading }) {
  const hasItems = Array.isArray(suggestions) && suggestions.length > 0
  if (!loading && !hasItems) return null

  return (
    <div className="mt-3 flex flex-col items-end">
      <div className="mb-2 flex items-center gap-1.5 text-caption text-text-tertiary">
        <Sparkles size={11} className="text-accent-blue" />
        <span>Suggested replies</span>
      </div>

      <div className="flex flex-wrap justify-end gap-2">
        <AnimatePresence initial={false} mode="wait">
          {loading ? (
            <motion.div
              key="skeleton"
              className="flex flex-wrap justify-end gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-8 w-32 animate-pulse rounded-pill bg-surface2"
                  style={{ width: `${112 + i * 16}px` }}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="chips"
              className="flex flex-wrap justify-end gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.18 }}
            >
              {suggestions.map((s, i) => (
                <motion.button
                  key={`${i}-${s.short}`}
                  type="button"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2, delay: i * 0.04 }}
                  onClick={() => {
                    haptic('light')
                    onPick(s)
                  }}
                  title={s.full}
                  className="flex max-w-[260px] items-center gap-1.5 rounded-pill border border-border bg-surface px-3 py-1.5 text-left text-body-sm text-text-secondary transition-colors hover:border-accent-blue/40 hover:bg-accent-blue/10 hover:text-accent-blue"
                >
                  <MessageSquarePlus size={12} className="shrink-0" />
                  <span className="truncate">{s.short}</span>
                </motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
